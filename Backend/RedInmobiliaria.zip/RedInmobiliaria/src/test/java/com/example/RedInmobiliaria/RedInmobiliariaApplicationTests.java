package com.example.RedInmobiliaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedInmobiliariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
