package com.example.RedInmobiliaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedInmobiliariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedInmobiliariaApplication.class, args);
	}

}
